const db = require('../db/database');

function getPlayerByDiscordUserId(discordUserId) {
  return db.prepare(`
    SELECT *
    FROM players
    WHERE discord_user_id = ?
  `).get(discordUserId);
}

function createPlayer({ discordUserId, discordUsername, pokemonKey, guildKey, guildRoleId = null }) {
  const now = new Date().toISOString();
  const result = db.prepare(`
    INSERT INTO players (
      discord_user_id,
      discord_username,
      pokemon_key,
      guild_key,
      guild_role_id,
      created_at,
      updated_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(discordUserId, discordUsername, pokemonKey, guildKey, guildRoleId, now, now);

  return db.prepare(`
    SELECT *
    FROM players
    WHERE id = ?
  `).get(result.lastInsertRowid);
}

function allPlayers() {
  return db.prepare(`SELECT * FROM players ORDER BY created_at ASC`).all();
}



function updatePlayerProgress(discordUserId, changes) {
  const fields = [];
  const values = [];

  if (typeof changes.xp === 'number') {
    fields.push('xp = xp + ?');
    values.push(changes.xp);
  }

  if (typeof changes.wood === 'number') {
    fields.push('wood = wood + ?');
    values.push(changes.wood);
  }

  if (typeof changes.food === 'number') {
    fields.push('food = food + ?');
    values.push(changes.food);
  }

  if (typeof changes.stone === 'number') {
    fields.push('stone = stone + ?');
    values.push(changes.stone);
  }

  if (typeof changes.contribution === 'number') {
    fields.push('contribution = contribution + ?');
    values.push(changes.contribution);
  }

  fields.push('updated_at = ?');
  values.push(new Date().toISOString());

  values.push(discordUserId);

  db.prepare(`
    UPDATE players
    SET ${fields.join(', ')}
    WHERE discord_user_id = ?
  `).run(...values);
}

function getCampTotals() {
  return db.prepare(`
    SELECT
      COUNT(*) as players,
      COALESCE(SUM(wood), 0) as wood,
      COALESCE(SUM(food), 0) as food,
      COALESCE(SUM(stone), 0) as stone,
      COALESCE(SUM(contribution), 0) as contribution
    FROM players
  `).get();
}

module.exports = {
  getPlayerByDiscordUserId,
  createPlayer,
  allPlayers,
  updatePlayerProgress,
  getCampTotals
};
