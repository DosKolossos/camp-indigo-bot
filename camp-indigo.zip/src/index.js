require('dotenv').config();

const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  Collection,
  MessageFlags
} = require('discord.js');

const pingCommand = require('./commands/ping');
const setupStartCommand = require('./commands/setup-start');
const startFlow = require('./interactions/startFlow');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.commands = new Collection();
client.commands.set(pingCommand.data.name, pingCommand);
client.commands.set(setupStartCommand.data.name, setupStartCommand);

async function registerCommands() {
  const commands = [
    pingCommand.data.toJSON(),
    setupStartCommand.data.toJSON()
  ];

  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  await rest.put(
    Routes.applicationGuildCommands(
      process.env.DISCORD_CLIENT_ID,
      process.env.DISCORD_GUILD_ID
    ),
    { body: commands }
  );

  console.log('Slash-Commands registriert.');
}

client.once('clientReady', async () => {
  console.log(`Eingeloggt als ${client.user.tag}`);
  await registerCommands();
});

client.on('interactionCreate', async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      await command.execute(interaction);
      return;
    }

    if (interaction.isButton() || interaction.isStringSelectMenu()) {
      if (startFlow.canHandleInteraction(interaction)) {
        await startFlow.handleInteraction(interaction);
      }
    }
  } catch (error) {
    console.error(error);

    const payload = {
      content: 'Beim Ausführen der Aktion ist ein Fehler aufgetreten.',
      flags: MessageFlags.Ephemeral
    };

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(payload).catch(() => null);
    } else if (interaction.isRepliable()) {
      await interaction.reply(payload).catch(() => null);
    }
  }
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;
  if (!message.guild) return;

  const prefix = '!';
  if (!message.content.startsWith(prefix)) return;

  const [rawCommand, ...args] = message.content.slice(prefix.length).trim().split(/\s+/);
  const command = rawCommand?.toLowerCase();

  try {
    if (command === 'profil') {
      const { handleProfilCommand } = require('./textCommands/profil');
      await handleProfilCommand(message);
      return;
    }

    if (command === 'sammeln') {
      const { handleSammelnCommand } = require('./textCommands/sammeln');
      await handleSammelnCommand(message);
      return;
    }

    if (command === 'arbeiten') {
      const { handleArbeitenCommand } = require('./textCommands/arbeiten');
      await handleArbeitenCommand(message);
      return;
    }

    if (command === 'lager') {
      const { handleLagerCommand } = require('./textCommands/lager');
      await handleLagerCommand(message);
      return;
    }
  } catch (error) {
    console.error(error);
    await message.reply('Dabei ist etwas schiefgelaufen.');
  }
});

client.login(process.env.DISCORD_TOKEN);